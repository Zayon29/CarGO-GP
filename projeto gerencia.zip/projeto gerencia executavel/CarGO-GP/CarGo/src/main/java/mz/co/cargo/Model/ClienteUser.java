package mz.co.cargo.Model;

public class ClienteUser extends User{

    public ClienteUser(String nome, String email, String senha) {
        super(nome, email, senha);
    }
}
