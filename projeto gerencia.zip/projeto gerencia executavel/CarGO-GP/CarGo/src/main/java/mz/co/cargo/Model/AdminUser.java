package mz.co.cargo.Model;

public class AdminUser extends User{

    public AdminUser(String nome, String email, String senha) {
        super( nome, email, senha);
    }
}
