# CarGO-GP
Projeto da Disciplina Gerência de Projetos
Consiste em um Sistema de alugueis de carros ultilizando JavaFX(frontend) e Java 20/21 no desenvolvimento

Para rodar o projeto, baixe "Projeto Gerencia.rar" no diretório do sistema e descopacte o arquivo que segue com mais instruções.